def printf(strings):
	print(strings)
